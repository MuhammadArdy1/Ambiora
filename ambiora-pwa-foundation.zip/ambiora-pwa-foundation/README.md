# AMBIORA PWA 1.0 — Foundation

Fondasi awal aplikasi ambient sound AMBIORA.

## Sudah dibuat
- UI mobile-first tema Dark Nature Premium.
- Navigasi Beranda, Mixer, Suara, Favorit, Pengaturan.
- Metadata katalog 24 suara, pencarian dan filter kategori.
- Tambah/hapus suara di mixer, batas maksimal 5 dan tanpa duplikat.
- Slider volume visual.
- Favorit tersimpan lokal melalui localStorage (sementara).
- Manifest PWA dan Service Worker untuk app shell.

## Belum dibuat
Audio asli, Audio Engine, timer, preset, IndexedDB, cache audio offline dan indikator kesiapan audio. Tombol Putar belum menghasilkan suara. Cache saat ini hanya untuk kerangka aplikasi.

## Deploy GitHub Pages
1. Buat repository GitHub, misalnya `ambiora`.
2. Ekstrak ZIP dan unggah seluruh isi folder ke root repository.
3. Buka Settings → Pages.
4. Pilih branch `main` dan folder `/ (root)`, lalu simpan.
5. Setelah alamat Pages aktif, buka melalui Chrome Android.
6. Pilih menu Chrome → Tambahkan ke layar utama jika tersedia.

Path memakai format relatif untuk mendukung repository subpath. Service Worker memerlukan HTTPS atau localhost. Belum diuji pada perangkat Android nyata.
